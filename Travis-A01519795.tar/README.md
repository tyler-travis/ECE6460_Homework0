# ECE6460 Homework0
This is an implementation of an AVL tree that will do the following:
- Creating tree
- Insertion of a node
- Deletion of a node
- Searching a node
- Deleting Tree
- Traversal of the tree - Pre-order, Post-order and In-order
- Check Balance
